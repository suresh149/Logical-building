
public class L8 {

	public static void main(String[] args) {
		for(int i=100;i>=0;i--)
		{
			System.out.print(i+" ");
		}


	}

}
