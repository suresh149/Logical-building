import java.util.Scanner;

public class L4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		 int n1,n2;
	
		 n1=sc.nextInt();
		 n2=sc.nextInt();
		 int n3=n1+n2;
		 if(n3%2==0)
		 {
			 System.out.println("The sum of "+n3+" is a even number" );
		 }
		 else
		 {
			 System.out.println("The sum of  "+n3+" is a odd number");
		 }
	}
}
