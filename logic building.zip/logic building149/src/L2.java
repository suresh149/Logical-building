import java.util.*;
public class L2
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
      
       int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        if(n1 > n2)
            System.out.print(n1 +" is greater");
        else
            System.out.print(n2 +" is greater");
    }
}